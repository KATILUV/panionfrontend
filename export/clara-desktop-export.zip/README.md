# Clara Desktop Application

## Overview
This package allows you to run Clara AI as a desktop application using Electron.

## Setup Instructions

### Prerequisites
- Node.js 18+ and npm

### Installation
1. Extract this ZIP archive
2. Run `npm install` to install dependencies
3. Create a `.env` file with your API keys (see .env.example)
4. Run `npm start` to launch the desktop application

### Environment Variables
Create a .env file with:
```
OPENAI_API_KEY=your_openai_key_here
# Optional: ANTHROPIC_API_KEY=your_anthropic_key_here
```

## Building Distributables
- Run `npm run make` to create distributables for your platform
- Find the created packages in the 'out' folder

## Features
- Run Clara AI as a native desktop application
- Full offline capabilities (once loaded)
- System tray integration
- Native notifications

## Technology
- Electron
- HTML/CSS/JavaScript
- OpenAI API integration
